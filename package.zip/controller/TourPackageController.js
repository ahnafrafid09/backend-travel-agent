const { TourPackage, Schedule, TimeSlot } = require("../models/TourPackage.js");
const Category = require("../models/Category.js");
const SubCategory = require("../models/SubCategory.js");
const { TourPackageFacilities } = require("../models/RelationManyToMany.js");
const Facility = require("../models/Facility.js");
const Translation = require("../models/Translation.js");
const path = require('path');
const fs = require("fs");
const { v4: uuidv4 } = require("uuid");
const { fileURLToPath } = require('url');
const { dirname } = require('path');

const GetTourPackage = async (req, res) => {
    const { lang } = req.query;
    try {
        const response = await TourPackage.findAll({
            attributes: ['id', 'image_url', 'price'],
            include: [
                {
                    model: Translation,
                    attributes: ["attribute", "value"],
                    where: lang ? { lang: lang } : {},
                    as: "translations"
                },
                {
                    model: Schedule,
                    attributes: ["day"],
                    include: [
                        {
                            model: TimeSlot,
                            attributes: ["hours"],
                            include: {
                                model: Translation,
                                attributes: ["attribute", "value"],
                                where: lang ? { lang: lang } : {},
                                as: "translations"
                            }
                        }
                    ]
                },
                {
                    model: Category,
                    attributes: ["slug", "id"],
                    include: {
                        model: Translation,
                        attributes: ["attribute", "value"],
                        where: lang ? { lang: lang } : {},
                        as: "translations"
                    }
                },
                {
                    model: SubCategory,
                    attributes: ["slug", "id"],
                    include: {
                        model: Translation,
                        attributes: ["attribute", "value"],
                        where: lang ? { lang: lang } : {},
                        as: "translations"
                    }
                },
                {
                    model: Facility,
                    through: {
                        model: TourPackageFacilities,
                    },
                    include: {
                        model: Translation,
                        attributes: ['value', 'attribute'],
                        where: lang ? { lang: lang } : {},
                        as: "translations",
                    }
                }
            ]
        });

        if (response.length === 0) {
            return res.status(404).json({
                statusCode: 404,
                status: "not found",
                message: "Tour Package Not Found"
            });
        }

        res.status(200).json({
            statusCode: 200,
            status: "success",
            message: "Tour Package Success",
            data: response
        });
    } catch (error) {
        console.error("Error fetching tour packages:", error);
        res.status(500).json({
            statusCode: 500,
            status: "internal server error",
            message: "internal server error", error: error
        });
    }
};


const GetTourPackageById = async (req, res) => {
    const { lang } = req.query
    const { id } = req.params
    try {
        const response = await TourPackage.findByPk(id, {
            attributes: ['id', 'image_url', 'price'],
            include: [
                {
                    model: Translation,
                    attributes: ["attribute", "value"],
                    where: lang ? { lang: lang } : {},
                    as: "translations"
                },
                {
                    model: Schedule,
                    attributes: ["day"],
                    include: [{
                        model: TimeSlot,
                        attributes: ["hours"],
                        include: {
                            model: Translation,
                            attributes: ["attribute", "value"],
                            where: lang ? { lang: lang } : {},
                            as: "translations"
                        }
                    }]
                },
                {
                    model: Category,
                    attributes: ["slug", "id"],
                    include: {
                        model: Translation,
                        attributes: ["attribute", "value"],
                        where: lang ? { lang: lang } : {},
                        as: "translations"
                    }
                }, {
                    model: SubCategory,
                    attributes: ["slug", "id"],
                    include: {
                        model: Translation,
                        attributes: ["attribute", "value"],
                        where: lang ? { lang: lang } : {},
                        as: "translations"
                    }
                }, {
                    model: Facility,
                    through: {
                        model: TourPackageFacilities,
                    },
                    include:
                    {
                        model: Translation,
                        attributes: ['value', 'attribute'],
                        where: lang ? { lang: lang } : lang,
                        as: "translations",
                    }
                }]
        })

        if (response.length === 0) return res.status(404).json({ statusCode: 404, status: "not found", message: "Tour Package Not Found" })
        res.status(200).json({ statusCode: 200, status: "success", message: "Tour Package Success", data: response })
    } catch (error) {
        console.log(error);
        res.status(500).json({ statusCode: 500, status: "internal server error", message: "internal server error", error: error })
    }
}

const CreateTourPackage = async (req, res) => {
    try {
        if (!req.files || !req.files.image) return res.status(400).json({ message: "No image file uploaded" });

        const image = req.files.image;
        const imageSize = image.data.length;
        const ext = path.extname(image.name).toLowerCase();
        const imageName = uuidv4() + ext;
        const allowedType = ['.jpg', '.png', '.jpeg'];
        const filePath = `public/tour-package/${imageName}`;
        const url = `${req.protocol}://${req.get("host")}/public/tour-package/${imageName}`;

        if (!allowedType.includes(ext)) {
            return res.status(422).json({ message: "Images must be jpeg, jpg, png format" });
        }
        if (imageSize > 2000000) {
            return res.status(422).json({ message: "Images should not be more than 2MB" });
        }

        await new Promise((resolve, reject) => {
            image.mv(filePath, (err) => {
                if (err) return reject(err);
                resolve();
            });
        });

        const { categoryId, subCategoryId, facilityId, schedules, translations, prices } = req.body;
        const parsedPrices = JSON.parse(prices);

        if (!Array.isArray(parsedPrices) || parsedPrices.length === 0) {
            return res.status(400).json({ message: "Price must be an array with price details" });
        }

        for (const priceGroup of parsedPrices) {
            if (priceGroup.package && typeof priceGroup.package !== 'string') {
                return res.status(400).json({ message: "If provided, package must be a string" });
            }

            if (!Array.isArray(priceGroup.price)) {
                return res.status(400).json({ message: "Each group must have an array of prices" });
            }

            for (const priceDetail of priceGroup.price) {
                if (typeof priceDetail.totalPerson === 'undefined' || typeof priceDetail.pricePerPerson === 'undefined') {
                    return res.status(400).json({ message: "Each price object must include totalPerson and pricePerPerson" });
                }
            }
        }

        const tourPackage = await TourPackage.create({
            categoryId,
            subCategoryId,
            price: parsedPrices,
            image_url: url
        });

        if (translations && translations.length > 0) {
            const translationData = JSON.parse(translations).flatMap(t => ([
                { entityId: tourPackage.id, lang: t.lang, entityType: 'tour_package', attribute: 'name_tour_package', value: t.name },
                { entityId: tourPackage.id, lang: t.lang, entityType: 'tour_package', attribute: 'desc_tour_package', value: t.tourdesc },
                { entityId: tourPackage.id, lang: t.lang, entityType: 'tour_package', attribute: 'destination_tour_package', value: JSON.stringify(t.destination) }
            ]));
            await Translation.bulkCreate(translationData);
        }

        if (schedules && schedules.length > 0) {
            const scheduleData = JSON.parse(schedules);
            for (const schedule of scheduleData) {
                const newSchedule = await Schedule.create({
                    tourPackageId: tourPackage.id,
                    day: schedule.day
                });
                for (const timeSlot of schedule.time) {
                    const newTimeSlot = await TimeSlot.create({
                        scheduleId: newSchedule.id,
                        hours: timeSlot.hours
                    });
                    if (timeSlot.translations && timeSlot.translations.length > 0) {
                        const timeSlotTranslations = timeSlot.translations.map(t => ({
                            entityId: newTimeSlot.id,
                            lang: t.lang,
                            entityType: 'time',
                            attribute: 'desc_schedule',
                            value: t.value
                        }));
                        await Translation.bulkCreate(timeSlotTranslations);
                    }
                }
            }
        }

        if (facilityId && facilityId.length > 0) {
            const facilityData = JSON.parse(facilityId).map(id => ({
                tourPackageId: tourPackage.id,
                facilityId: id,
            }));
            await TourPackageFacilities.bulkCreate(facilityData);
        }

        res.status(201).json({ statusCode: 201, status: "created", message: "Tour Package Created", data: tourPackage });
    } catch (error) {
        console.log(error);
        res.status(500).json({ statusCode: 500, status: "internal server error", message: "internal server error", error: error });
    }
};


const UpdateTourPackage = async (req, res) => {
    try {
        const { id } = req.params;

        const tourPackage = await TourPackage.findByPk(id);
        if (!tourPackage) {
            return res.status(404).json({ message: "Tour Package not found" });
        }

        let imageUrl = tourPackage.image_url;
        if (req.files && req.files.image) {
            const image = req.files.image;
            const imageSize = image.data.length;
            const ext = path.extname(image.name).toLowerCase();
            const imageName = uuidv4() + ext;
            const allowedType = ['.jpg', '.png', '.jpeg'];
            imageUrl = `${req.protocol}://${req.get("host")}/public/tour-package/${imageName}`;

            if (!allowedType.includes(ext)) {
                return res.status(422).json({ message: "Images must be jpeg, jpg, png format" });
            }
            if (imageSize > 2000000) {
                return res.status(422).json({ message: "Images should not be more than 2MB" });
            }


            const oldFilePath = path.join(__dirname, '..', 'public', 'tour-package', path.basename(tourPackage.image_url));
            if (fs.existsSync(oldFilePath)) {
                fs.unlinkSync(oldFilePath);
            }

            await new Promise((resolve, reject) => {
                image.mv(`public/tour-package/${imageName}`, (err) => {
                    if (err) return reject(err);
                    resolve();
                });
            });
        }

        const { categoryId, subCategoryId, facilityId, schedules, translations, prices } = req.body;

        const updatedData = {
            categoryId,
            subCategoryId,
            image_url: imageUrl,
        }

        if (prices) {
            const parsedPrices = JSON.parse(prices);

            if (!Array.isArray(parsedPrices) || parsedPrices.length === 0) {
                return res.status(400).json({ message: "Price must be an array with price details" });
            }

            for (const priceGroup of parsedPrices) {
                if (priceGroup.package && typeof priceGroup.package !== 'string') {
                    return res.status(400).json({ message: "If provided, package must be a string" });
                }

                if (!Array.isArray(priceGroup.prices)) {
                    return res.status(400).json({ message: "Each group must have an array of prices" });
                }

                for (const priceDetail of priceGroup.price) {
                    if (typeof priceDetail.totalPerson === 'undefined' || typeof priceDetail.pricePerPerson === 'undefined') {
                        return res.status(400).json({ message: "Each price object must include totalPerson and pricePerPerson" });
                    }
                }
            }
            updatedData.price = parsedPrices;
        }

        await tourPackage.update(updatedData);

        if (translations && translations.length > 0) {
            const combinedTranslations = [];
            const translationData = JSON.parse(translations);

            const translationNameData = translationData.map(t => ({
                entityId: tourPackage.id,
                lang: t.lang,
                entityType: 'tour_package',
                attribute: 'name_tour_package',
                value: t.name
            }));

            const translationDescData = translationData.map(t => ({
                entityId: tourPackage.id,
                lang: t.lang,
                entityType: 'tour_package',
                attribute: 'desc_tour_package',
                value: t.tourdesc
            }));

            combinedTranslations.push(...translationNameData, ...translationDescData);
            await Translation.bulkCreate(combinedTranslations, { updateOnDuplicate: ["value"] });
        }

        if (schedules) {
            const parsedSchedules = JSON.parse(schedules);
            await Schedule.destroy({ where: { tourPackageId: id } });

            for (const schedule of parsedSchedules) {
                const newSchedule = await Schedule.create({
                    tourPackageId: id,
                    day: schedule.day
                });

                for (const timeSlot of schedule.time) {
                    const newTimeSlot = await TimeSlot.create({
                        scheduleId: newSchedule.id,
                        hours: timeSlot.hours
                    });

                    if (timeSlot.translations && timeSlot.translations.length > 0) {
                        const timeSlotTranslations = timeSlot.translations.map(t => ({
                            entityId: newTimeSlot.id,
                            lang: t.lang,
                            entityType: 'time',
                            attribute: 'desc_schedule',
                            value: t.value
                        }));
                        await Translation.bulkCreate(timeSlotTranslations);
                    }
                }
            }
        }

        if (facilityId) {
            const tourPackageFacilities = JSON.parse(facilityId).map(facilityId => ({
                tourPackageId: tourPackage.id,
                facilityId,
            }));
            await TourPackageFacilities.bulkCreate(tourPackageFacilities, { updateOnDuplicate: ["facilityId"] });
        }

        res.status(200).json({ statusCode: 200, status: "updated", message: "Tour Package Updated" });

    } catch (error) {
        console.log(error);
        res.status(500).json({ statusCode: 500, status: "internal server error", message: "internal server error", error: error });
    }
};


const DeleteTourPackage = async (req, res) => {
    try {
        const { id } = req.params;

        const tourPackage = await TourPackage.findByPk(id);
        if (!tourPackage) {
            return res.status(404).json({ message: "Tour Package not found" });
        }

        const imagePath = tourPackage.image_url.split(`${req.protocol}://${req.get("host")}/`)[1];
        if (fs.existsSync(imagePath)) {
            fs.unlinkSync(imagePath);
        }

        // Hapus fasilitas yang terkait
        await TourPackageFacilities.destroy({ where: { tourPackageId: id } });

        // Hapus jadwal yang terkait
        await Schedule.destroy({ where: { tourPackageId: id } });

        // Hapus terjemahan yang terkait
        await Translation.destroy({ where: { entityId: id, entityType: 'tour_package' } });

        // Hapus paket tur
        await tourPackage.destroy();

        res.status(200).json({ statusCode: 200, status: 'deleted', message: 'Tour Package deleted successfully' });
    } catch (error) {
        console.log(error);
        res.status(500).json({ statusCode: 500, status: "internal server error", message: "internal server error", error: error });
    }
};

module.exports = {
    GetTourPackage,
    GetTourPackageById,
    CreateTourPackage,
    UpdateTourPackage,
    DeleteTourPackage
}