const { DataTypes } = require('sequelize');
const sequelize = require('../config/database.js');
const Category = require('./Category.js');
const SubCategory = require('./SubCategory.js');
const Translation = require('./Translation.js');

const TourPackage = sequelize.define('tour_package', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    image_url: {
        type: DataTypes.STRING,
        allowNull: false
    },
    price: {
        type: DataTypes.JSON,
        allowNull: false
    },
    categoryId: {
        type: DataTypes.INTEGER,
        references: {
            model: Category,
            key: "id"
        }
    },
    subCategoryId: {
        type: DataTypes.INTEGER,
        references: {
            model: SubCategory,
            key: "id"
        }
    }
}, {
    timestamps: true,
    freezeTableName: true
});

const Schedule = sequelize.define('schedule', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    tourPackageId: {
        type: DataTypes.INTEGER,
        references: {
            model: TourPackage,
            key: 'id'
        },
        allowNull: false
    },
    day: {
        type: DataTypes.STRING,
        allowNull: false
    },
}, {
    freezeTableName: true,
    timestamps: true
});

const TimeSlot = sequelize.define('timeSlot', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    scheduleId: {
        type: DataTypes.INTEGER,
        references: {
            model: Schedule,
            key: 'id'
        },
        allowNull: false
    },
    hours: {
        type: DataTypes.STRING,
        allowNull: false
    }
}, {
    freezeTableName: true,
    timestamps: true
});

// Associations
Schedule.hasMany(TimeSlot, { foreignKey: 'scheduleId', onDelete: 'CASCADE' });
TimeSlot.belongsTo(Schedule, { foreignKey: 'scheduleId' });

TourPackage.hasMany(Schedule, { foreignKey: 'tourPackageId' });
Schedule.belongsTo(TourPackage, { foreignKey: 'tourPackageId' });

Category.hasMany(TourPackage, { foreignKey: 'categoryId' });
TourPackage.belongsTo(Category, { foreignKey: 'categoryId' });

SubCategory.hasMany(TourPackage, { foreignKey: 'subCategoryId' });
TourPackage.belongsTo(SubCategory, { foreignKey: 'subCategoryId' });

module.exports = {
    TourPackage,
    Schedule,
    TimeSlot
};
