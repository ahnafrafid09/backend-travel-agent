const { DataTypes } = require("sequelize");
const sequelize = require("../config/database.js");
const Category = require("./Category.js");

const Travel = sequelize.define('travel', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    image_url: {
        type: DataTypes.STRING,
        allowNull: false
    },
    price: {
        type: DataTypes.STRING,
        allowNull: false
    },
    departure_schedule: {
        type: DataTypes.STRING,
        allowNull: false
    },
    departure_place: {
        type: DataTypes.STRING,
        allowNull: false
    },
    departure_destination: {
        type: DataTypes.STRING,
        allowNull: false
    },
    categoryId: {
        type: DataTypes.INTEGER,
        references: {
            model: Category,
            key: "id"
        }
    },
}, {
    freezeTableName: true,
    timestamps: true
})



Category.hasMany(Travel, { foreignKey: 'categoryId' });
Travel.belongsTo(Category, { foreignKey: 'categoryId' });


module.exports = Travel