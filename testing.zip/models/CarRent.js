const { DataTypes } = require('sequelize');
const sequelize = require('../config/database.js');
const Category = require('./Category.js');
const SubCategory = require('./SubCategory.js');

const CarRent = sequelize.define('car_rent', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    car_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    image_url: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    price: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    capacity: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    model_year: {
        type: DataTypes.STRING,
        allowNull: false
    },
    categoryId: {
        type: DataTypes.INTEGER,
        references: {
            model: Category,
            key: 'id'
        }
    },
    subCategoryId: {
        type: DataTypes.INTEGER,
        references: {
            model: SubCategory,
            key: 'id'
        }
    }
}, {
    freezeTableName: true,
    timestamps: true
});

// Define relationships
Category.hasMany(CarRent, { foreignKey: 'categoryId' });
CarRent.belongsTo(Category, { foreignKey: 'categoryId' });

SubCategory.hasMany(CarRent, { foreignKey: 'subCategoryId' });
CarRent.belongsTo(SubCategory, { foreignKey: 'subCategoryId' });

module.exports = CarRent;
