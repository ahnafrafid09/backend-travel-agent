const Category = require("./Category.js");
const Facility = require("./Facility.js");
const SubCategory = require("./SubCategory.js");
const CarRent = require("./CarRent.js");
const Travel = require("./Travel.js");
const { Schedule, TourPackage, TimeSlot } = require("./TourPackage.js");
const Translation = require("./Translation.js");

Category.hasMany(Translation, {
    foreignKey: "entityId",
    constraints: false,
    scope: {
        entityType: "category"
    },
    as: 'translations'
});

Facility.hasMany(Translation, {
    foreignKey: "entityId",
    constraints: false,
    scope: {
        entityType: "facility"
    },
    as: 'translations'
});

SubCategory.hasMany(Translation, {
    foreignKey: "entityId",
    constraints: false,
    scope: {
        entityType: "sub_category"
    },
    as: 'translations'
});

TourPackage.hasMany(Translation, {
    foreignKey: "entityId",
    constraints: false,
    scope: {
        entityType: "tour_package"
    },
    as: 'translations'
});

Schedule.hasMany(Translation, {
    foreignKey: "entityId",
    constraints: false,
    scope: {
        entityType: "schedule"
    },
    as: 'translations'
});

Travel.hasMany(Translation, {
    foreignKey: "entityId",
    constraints: false,
    scope: {
        entityType: "travel"
    },
    as: 'translations'
});

TimeSlot.hasMany(Translation, {
    foreignKey: "entityId",
    constraints: false,
    scope: {
        entityType: "time"
    },
    as: 'translations'
});

module.exports = { Category, Translation, Travel, SubCategory, TourPackage, Schedule, Facility, TimeSlot };
